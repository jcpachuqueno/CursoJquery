//
// jQuery
// Ejercicio 2
//

$(document).ready(function()
{        
    $('.button').click(function()
    {       
            
    });    
    
});